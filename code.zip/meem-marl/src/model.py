"""
MEEM-MARL model architecture (the pipeline).

Implements:
- Per-modality encoders (Step 2): 1D-CNN (eye), CNN-FACS (face),
  Transformer (voice), LSTM (physio), MLP (logs).
- Attention-weighted late fusion (Step 3).
- Latent state estimation heads (Step 4).
- Three-stage moral modeling module (Step 5).
- Outcome prediction heads (Step 6).
- Q-learning policy (Step 7).
- Composite loss  and dependence-penalty reward .
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from . import config as C

# ============================================================
# Step 2 - Per-modality encoders
# ============================================================
class EyeEncoder(nn.Module):
    """1-D CNN over eye-tracking channels (fixation, pupil, saccade)."""
    def __init__(self, in_channels=4, out_dim=C.FUSED_FEATURE_DIM):
        super().__init__()
        self.conv1 = nn.Conv1d(in_channels, 32, kernel_size=5, padding=2)
        self.conv2 = nn.Conv1d(32, 64, kernel_size=3, padding=1)
        self.pool  = nn.AdaptiveAvgPool1d(1)
        self.proj  = nn.Linear(64, out_dim)

    def forward(self, x):
        # x: (B, in_channels, T)
        h = F.relu(self.conv1(x))
        h = F.relu(self.conv2(h))
        h = self.pool(h).squeeze(-1)
        return self.proj(h)

class FaceEncoder(nn.Module):
    """CNN over facial action units (17 AU intensities + 68 landmarks)."""
    def __init__(self, n_features=85, out_dim=C.FUSED_FEATURE_DIM):
        super().__init__()
        self.conv1 = nn.Conv1d(n_features, 64, kernel_size=3, padding=1)
        self.conv2 = nn.Conv1d(64, 64, kernel_size=3, padding=1)
        self.pool  = nn.AdaptiveAvgPool1d(1)
        self.proj  = nn.Linear(64, out_dim)

    def forward(self, x):
        # x: (B, n_features, T)
        h = F.relu(self.conv1(x))
        h = F.relu(self.conv2(h))
        h = self.pool(h).squeeze(-1)
        return self.proj(h)

class VoiceEncoder(nn.Module):
    """Transformer over eGeMAPS acoustic features (F0, intensity, MFCC ...)."""
    def __init__(self, n_features=88, d_model=64, n_heads=4,
                 out_dim=C.FUSED_FEATURE_DIM):
        super().__init__()
        self.embed = nn.Linear(n_features, d_model)
        layer = nn.TransformerEncoderLayer(d_model, n_heads, dim_feedforward=128,
                                           batch_first=True)
        self.encoder = nn.TransformerEncoder(layer, num_layers=2)
        self.proj = nn.Linear(d_model, out_dim)

    def forward(self, x):
        # x: (B, T, n_features)
        h = self.embed(x)
        h = self.encoder(h)
        h = h.mean(dim=1)
        return self.proj(h)

class PhysioEncoder(nn.Module):
    """LSTM over HRV and EDA channels."""
    def __init__(self, n_features=6, hidden=64, out_dim=C.FUSED_FEATURE_DIM):
        super().__init__()
        self.lstm = nn.LSTM(n_features, hidden, batch_first=True,
                             num_layers=1, bidirectional=False)
        self.proj = nn.Linear(hidden, out_dim)

    def forward(self, x):
        # x: (B, T, n_features)
        h, _ = self.lstm(x)
        h = h[:, -1, :]
        return self.proj(h)

class LogsEncoder(nn.Module):
    """MLP over aggregated interaction-log features."""
    def __init__(self, n_features=10, hidden=64, out_dim=C.FUSED_FEATURE_DIM):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(n_features, hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.ReLU(),
            nn.Linear(hidden, out_dim),
        )

    def forward(self, x):
        return self.net(x)

# ============================================================
# Step 3 - Attention-weighted late fusion
# ============================================================
class AttentionFusion(nn.Module):
    """
    alpha_m = softmax(w_a^T * F_m + b_a)
    F_fused = sum_m alpha_m * F_m
    """
    def __init__(self, feature_dim=C.FUSED_FEATURE_DIM, n_modalities=6):
        super().__init__()
        self.w_a = nn.Parameter(torch.randn(feature_dim) * 0.01)
        self.b_a = nn.Parameter(torch.zeros(1))
        self.n_modalities = n_modalities

    def forward(self, features):
        # features: list of (B, D) tensors, one per modality
        # Compute score per modality
        scores = torch.stack(
            [(f * self.w_a).sum(dim=-1) + self.b_a for f in features], dim=1
        )  # (B, M)
        alphas = F.softmax(scores, dim=1)                            # (B, M)
        fused = sum(alphas[:, i:i + 1] * features[i]
                    for i in range(len(features)))
        return fused, alphas

# ============================================================
# Step 4 - Latent state heads
# ============================================================
class AffectEstimator(nn.Module):
    """
    CNN-LSTM affect estimator producing 7-class emotion + valence/arousal.
    
    """
    def __init__(self, feature_dim=C.FUSED_FEATURE_DIM,
                 hidden=64, n_classes=len(C.EMOTION_CLASSES)):
        super().__init__()
        self.temporal = nn.LSTM(feature_dim, hidden, batch_first=True)
        self.classifier = nn.Linear(hidden, n_classes)
        self.regressor  = nn.Linear(hidden, 2)          # valence, arousal

    def forward(self, x):
        # x: (B, T, feature_dim); if T dim absent, add dummy
        if x.dim() == 2:
            x = x.unsqueeze(1)
        h, _ = self.temporal(x)
        h_last = h[:, -1, :]
        logits = self.classifier(h_last)
        va = torch.tanh(self.regressor(h_last))
        return logits, va, h_last

class EngagementPresenceHead(nn.Module):
    """Two-headed MLP producing engagement and social-presence scalars."""
    def __init__(self, feature_dim=C.FUSED_FEATURE_DIM, hidden=32):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(feature_dim, hidden), nn.ReLU(),
            nn.Linear(hidden, 2),
        )

    def forward(self, f):
        return self.net(f)          # (B, 2): (engagement, presence)

class CognitiveLoadHead(nn.Module):
    """Regression head for cognitive load CL_t."""
    def __init__(self, feature_dim=C.FUSED_FEATURE_DIM, hidden=32):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(feature_dim, hidden), nn.ReLU(),
            nn.Linear(hidden, 1),
        )

    def forward(self, f):
        return self.net(f).squeeze(-1)

# ============================================================
# Step 5 - Three-stage moral modeling module
# ============================================================
class MoralModelingModule(nn.Module):
    """
    Three-stage latent representation:
        z_a  = Attention(F_fused, Theta_VI)
        z_r  = Retention(z_a, M_mem)
        z_p  = Reproduction(z_r, C_content)
    """
    def __init__(self, feature_dim=C.FUSED_FEATURE_DIM,
                 out_dim=C.LATENT_STATE_DIM):
        super().__init__()
        self.attention   = nn.Linear(feature_dim, out_dim)
        self.retention   = nn.GRU(out_dim, out_dim, batch_first=True)
        self.reproduction = nn.Linear(out_dim, out_dim)

    def forward(self, f_fused, memory=None):
        z_a = torch.tanh(self.attention(f_fused))
        if z_a.dim() == 2:
            z_a_seq = z_a.unsqueeze(1)
        else:
            z_a_seq = z_a
        z_r, _ = self.retention(z_a_seq)
        z_r = z_r[:, -1, :]
        z_p = torch.tanh(self.reproduction(z_r))
        return z_p, z_r, z_a

# ============================================================
# Step 6 - Outcome prediction heads
# ============================================================
class OutcomeHead(nn.Module):
    """Predict Y_MC, Y_ME, Y_BI from z_p and latent state."""
    def __init__(self, latent_dim=C.LATENT_STATE_DIM, extra_dim=64 + 1):
        super().__init__()
        self.mc = nn.Linear(latent_dim + extra_dim, 1)
        self.me = nn.Linear(latent_dim + extra_dim, 1)
        # BI uses moral emotion prediction as auxiliary input
        self.bi = nn.Linear(latent_dim + extra_dim + 1, 1)

    def forward(self, z_p, e_t, eng_t, pres_t):
        base = torch.cat([z_p, e_t, eng_t.unsqueeze(-1)], dim=-1)
        y_mc = torch.sigmoid(self.mc(base)).squeeze(-1)
        base_me = torch.cat([z_p, e_t, pres_t.unsqueeze(-1)], dim=-1)
        y_me = torch.sigmoid(self.me(base_me)).squeeze(-1)
        base_bi = torch.cat([z_p, e_t, y_me.unsqueeze(-1),
                             pres_t.unsqueeze(-1)], dim=-1)
        y_bi = torch.sigmoid(self.bi(base_bi)).squeeze(-1)
        return y_mc, y_me, y_bi

# ============================================================
# Full MEEM-MARL model
# ============================================================
class MEEMMARL(nn.Module):
    def __init__(self):
        super().__init__()
        self.eye_enc   = EyeEncoder()
        self.face_enc  = FaceEncoder()
        self.voice_enc = VoiceEncoder()
        self.physio_enc = PhysioEncoder()
        self.logs_enc  = LogsEncoder()
        self.fusion    = AttentionFusion(n_modalities=len(C.MODALITIES))
        self.affect    = AffectEstimator()
        self.eng_pres  = EngagementPresenceHead()
        self.cog_load  = CognitiveLoadHead()
        self.moral     = MoralModelingModule()
        self.outcome   = OutcomeHead()

    def forward(self, inputs):
        """
        inputs: dict with keys 'eye', 'face', 'voice', 'hrv', 'eda', 'logs'.
        Returns dict of tensors covering every downstream head.
        """
        f_eye   = self.eye_enc(inputs["eye"])
        f_face  = self.face_enc(inputs["face"])
        f_voice = self.voice_enc(inputs["voice"])
        # HRV + EDA share the physiological encoder
        f_physio = self.physio_enc(inputs["physio"])
        f_logs  = self.logs_enc(inputs["logs"])
        features = [f_eye, f_face, f_voice, f_physio, f_logs]
        # Pad to 6 modalities (EEG placeholder = zero features)
        if len(features) < 6:
            features.append(torch.zeros_like(f_eye))

        fused, alphas = self.fusion(features)
        logits, va, e_t = self.affect(fused)
        eng_pres = self.eng_pres(fused)
        eng_t, pres_t = eng_pres[:, 0], eng_pres[:, 1]
        cl_t = self.cog_load(fused)
        z_p, z_r, z_a = self.moral(fused)
        y_mc, y_me, y_bi = self.outcome(z_p, e_t, eng_t, pres_t)
        return {
            "affect_logits": logits,
            "affect_va": va,
            "e_t": e_t,
            "engagement": eng_t,
            "presence": pres_t,
            "cognitive_load": cl_t,
            "z_a": z_a, "z_r": z_r, "z_p": z_p,
            "y_mc": y_mc, "y_me": y_me, "y_bi": y_bi,
            "attention_weights": alphas,
        }

# ============================================================
#Composite loss
# ============================================================
def composite_loss(outputs, targets,
                    lam_aff=C.LAMBDA_AFF,
                    lam_moral=C.LAMBDA_MORAL,
                    lam_reg=C.LAMBDA_REG,
                    parameters=None):
    """
    L_total = lam_aff * L_aff + lam_moral * L_moral + lam_reg * ||theta||^2
    L_aff:  cross-entropy over 7 emotion classes + MSE for valence/arousal
    L_moral: MSE for predicted MC/ME/BI vs. targets
    """
    ce = F.cross_entropy(outputs["affect_logits"], targets["emotion_class"])
    mse_va = F.mse_loss(outputs["affect_va"], targets["valence_arousal"])
    L_aff = ce + 0.5 * mse_va

    mse_mc = F.mse_loss(outputs["y_mc"], targets["y_mc"])
    mse_me = F.mse_loss(outputs["y_me"], targets["y_me"])
    mse_bi = F.mse_loss(outputs["y_bi"], targets["y_bi"])
    L_moral = mse_mc + mse_me + mse_bi

    reg = torch.tensor(0.0)
    if parameters is not None:
        for p in parameters:
            reg = reg + (p ** 2).sum()

    return lam_aff * L_aff + lam_moral * L_moral + lam_reg * reg

# ============================================================
#Reward with dependence penalty
# ============================================================
def compute_reward(delta_mc, delta_me, delta_bi, cog_load, dependence,
                    w1=C.REWARD_W_MC, w2=C.REWARD_W_ME, w3=C.REWARD_W_BI,
                    w4=C.REWARD_W_CL, w5=C.REWARD_W_D):
    """
    R_t = w1 * dMC + w2 * dME + w3 * dBI - w4 * CL_t - w5 * D_t
    """
    return (w1 * delta_mc + w2 * delta_me + w3 * delta_bi
             - w4 * cog_load - w5 * dependence)

# ============================================================
# Q-learning tabular policy
# ============================================================
class QLearningPolicy:
    """
    Tabular Q(s, a) with epsilon-greedy exploration and epsilon annealing
    over the first C.EPS_ANNEAL_WIN windows .
    """
    def __init__(self, state_bins=6, n_state_features=5, actions=C.ACTIONS,
                 gamma=C.DISCOUNT_GAMMA, lr=C.LR_Q,
                 eps_start=C.EPS_START, eps_end=C.EPS_END,
                 seed=C.GLOBAL_SEED):
        import numpy as np
        self.np = np
        self.actions = list(actions)
        self.n_actions = len(actions)
        self.state_bins = state_bins
        self.n_state_features = n_state_features
        self.gamma = gamma
        self.lr = lr
        self.eps_start = eps_start
        self.eps_end = eps_end
        self.rng = np.random.default_rng(seed)
        self.Q = {}
        self.step = 0

    def _key(self, state):
        # Discretize continuous state into bins
        binned = tuple(
            int(min(max(v * self.state_bins, 0), self.state_bins - 1))
            for v in state
        )
        return binned

    def _epsilon(self):
        if self.step >= C.EPS_ANNEAL_WIN:
            return self.eps_end
        t = self.step / C.EPS_ANNEAL_WIN
        return self.eps_start + (self.eps_end - self.eps_start) * t

    def select(self, state):
        key = self._key(state)
        q_vec = self.Q.get(key, self.np.zeros(self.n_actions))
        if self.rng.random() < self._epsilon():
            return int(self.rng.integers(0, self.n_actions))
        return int(self.np.argmax(q_vec))

    def update(self, state, action, reward, next_state):
        key      = self._key(state)
        next_key = self._key(next_state)
        q_vec    = self.Q.setdefault(key, self.np.zeros(self.n_actions))
        q_next   = self.Q.get(next_key, self.np.zeros(self.n_actions))
        td_target = reward + self.gamma * q_next.max()
        td_error  = td_target - q_vec[action]
        q_vec[action] += self.lr * td_error
        self.step += 1
        return abs(td_error)

    def policy_star(self, state):
        key = self._key(state)
        q_vec = self.Q.get(key, self.np.zeros(self.n_actions))
        return self.actions[int(self.np.argmax(q_vec))]

    def warm_start(self, transitions):
        """Offline warm start on the pilot corpus's 57,600 transitions."""
        for s, a, r, sp in transitions:
            self.update(s, a, r, sp)

# ============================================================
# Latency measurement
# ============================================================
def measure_latency(model, sample_inputs, n_runs=100):
    """Measure end-to-end forward-pass latency."""
    import time
    times = []
    model.eval()
    with torch.no_grad():
        for _ in range(n_runs):
            t0 = time.perf_counter()
            _ = model(sample_inputs)
            t1 = time.perf_counter()
            times.append((t1 - t0) * 1000.0)
    return {
        "median_ms":   float(sorted(times)[len(times) // 2]),
        "p95_ms":      float(sorted(times)[int(len(times) * 0.95)]),
        "p99_ms":      float(sorted(times)[int(len(times) * 0.99)]),
        "max_ms":      float(max(times)),
        "pct_under_100ms": float(sum(t < 100 for t in times) / n_runs * 100),
    }
