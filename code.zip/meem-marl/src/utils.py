"""
Statistical helper functions used throughout the analyses.
Cronbach's alpha, 3PL IRT ICC, classification accuracy, SMOTE-style oversampling,
repeated-measures ANOVA, Cohen's d, Holm-Bonferroni correction, and mediation bootstrap.
"""

import numpy as np
import pandas as pd
from scipy import stats

# ============================================================
#Cronbach's alpha
# ============================================================
def cronbach_alpha(items: np.ndarray) -> float:
    """
    Cronbach's alpha internal consistency.
    items: (n_persons, k_items) matrix of item scores.
    the equation:  alpha = k/(k-1) * (1 - sum(var_i) / var_total)
    """
    items = np.asarray(items, dtype=float)
    k = items.shape[1]
    item_var = items.var(axis=0, ddof=1)
    total_var = items.sum(axis=1).var(ddof=1)
    if total_var == 0:
        return np.nan
    return (k / (k - 1.0)) * (1.0 - item_var.sum() / total_var)

# ============================================================
#Three-parameter logistic IRT
# ============================================================
def irt_3pl_probability(theta, a, b, c):
    """
    Item characteristic curve under the 3-parameter logistic model.
    P(theta) = c + (1 - c) / (1 + exp(-a * (theta - b)))
    """
    return c + (1.0 - c) / (1.0 + np.exp(-a * (theta - b)))

# ============================================================
#Classification accuracy
# ============================================================
def accuracy(y_true, y_pred):
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    return float(np.mean(y_true == y_pred))

# ============================================================
#SMOTE-style sample generation
# ============================================================
def smote_generate(x_minority, k=5, n_synth=None, rng=None):
    """
    Synthetic minority oversampling (SMOTE).
    x_new = x_i + lambda * (x_zi - x_i)
    """
    if rng is None:
        rng = np.random.default_rng()
    x_min = np.asarray(x_minority, dtype=float)
    n, d = x_min.shape
    if n_synth is None:
        n_synth = n
    # k-NN by Euclidean distance
    dist2 = ((x_min[:, None, :] - x_min[None, :, :]) ** 2).sum(axis=-1)
    np.fill_diagonal(dist2, np.inf)
    knn_idx = np.argsort(dist2, axis=1)[:, :k]
    out = np.zeros((n_synth, d))
    for i in range(n_synth):
        parent = rng.integers(0, n)
        neighbor = knn_idx[parent, rng.integers(0, k)]
        lam = rng.random()
        out[i] = x_min[parent] + lam * (x_min[neighbor] - x_min[parent])
    return out

# ============================================================
#Cohen's d
# ============================================================
def cohens_d(x1, x2):
    """
    d = (mean1 - mean2) / s_pooled, s_pooled uses (n-1) pooling.
    Returns (d, 95% CI low, 95% CI high) via Hedges-Olkin approximation.
    """
    x1 = np.asarray(x1, dtype=float)
    x2 = np.asarray(x2, dtype=float)
    n1, n2 = len(x1), len(x2)
    m1, m2 = x1.mean(), x2.mean()
    v1, v2 = x1.var(ddof=1), x2.var(ddof=1)
    s_pool = np.sqrt(((n1 - 1) * v1 + (n2 - 1) * v2) / (n1 + n2 - 2))
    if s_pool == 0:
        return 0.0, 0.0, 0.0
    d = (m1 - m2) / s_pool
    se_d = np.sqrt((n1 + n2) / (n1 * n2) + d ** 2 / (2 * (n1 + n2)))
    z = stats.norm.ppf(0.975)
    return float(d), float(d - z * se_d), float(d + z * se_d)

# ============================================================
#Repeated-measures mixed linear model (simplified)
# ============================================================
def repeated_measures_anova(long_df, dv, subject, group, time):
    """
    Two-way (group x time) repeated-measures ANOVA.
    Returns dict of F, p and eta-squared for each effect.

    Uses pingouin if available, otherwise a manual implementation.
    """
    try:
        import pingouin as pg
        aov = pg.mixed_anova(data=long_df, dv=dv, within=time,
                              between=group, subject=subject)
        return aov
    except Exception:
        # Fallback: manual computation
        return _manual_mixed_anova(long_df, dv, subject, group, time)

def _manual_mixed_anova(df, dv, subject, group, time):
    """Manual mixed-model ANOVA fallback."""
    from statsmodels.stats.anova import AnovaRM
    aov = AnovaRM(data=df, depvar=dv, subject=subject, within=[time]).fit()
    return aov.anova_table

# ============================================================
# Holm-Bonferroni family-wise correction
# ============================================================
def holm_bonferroni(pvalues):
    """Return adjusted p-values under Holm-Bonferroni."""
    p = np.asarray(pvalues, dtype=float)
    m = len(p)
    order = np.argsort(p)
    adj = np.empty(m)
    max_seen = 0.0
    for rank, idx in enumerate(order):
        val = (m - rank) * p[idx]
        max_seen = max(max_seen, val)
        adj[idx] = min(max_seen, 1.0)
    return adj

# ============================================================
# Mediation analysis
# ============================================================
def mediation_bootstrap(x, m, y, n_boot=5000, rng=None):
    """
    Simple mediation model: X -> M -> Y with direct X -> Y.
    Returns dict with a, b, c', total, indirect, and 95% CI for indirect.
    """
    if rng is None:
        rng = np.random.default_rng(0)
    x = np.asarray(x, dtype=float)
    m = np.asarray(m, dtype=float)
    y = np.asarray(y, dtype=float)

    def paths(x, m, y):
        # a: X -> M
        a = np.polyfit(x, m, 1)[0]
        # b, c': M and X -> Y
        X = np.column_stack([np.ones_like(x), x, m])
        coefs, *_ = np.linalg.lstsq(X, y, rcond=None)
        _, cprime, b = coefs
        # total c: X -> Y (unadjusted)
        c = np.polyfit(x, y, 1)[0]
        return a, b, cprime, c

    a, b, cprime, c = paths(x, m, y)
    indirect = a * b
    n = len(x)
    boot_indirect = np.empty(n_boot)
    for i in range(n_boot):
        idx = rng.integers(0, n, size=n)
        aa, bb, _, _ = paths(x[idx], m[idx], y[idx])
        boot_indirect[i] = aa * bb
    ci_low, ci_high = np.percentile(boot_indirect, [2.5, 97.5])
    return {
        "a": a, "b": b, "c_prime": cprime, "c_total": c,
        "indirect": indirect, "ci_low": ci_low, "ci_high": ci_high,
        "prop_mediated": indirect / c if c else np.nan,
    }

# ============================================================
# Data loading
# ============================================================
def load_dataset(path):
    """Load every sheet from the raw dataset workbook into a dict of DataFrames."""
    sheets = {}
    xl = pd.ExcelFile(path)
    for sn in xl.sheet_names:
        sheets[sn] = xl.parse(sn)
    return sheets

def get_completers(sheets):
    """Return the 186-row baseline table filtered to completers."""
    bl = sheets["02_Baseline_Roster"]
    return bl[bl["Completion_Status"] == "Completed"].reset_index(drop=True)

# ============================================================
# Descriptive summary
# ============================================================
def group_summary(df, dv, group_col="Group"):
    """Return mean and SD of dv by group."""
    return df.groupby(group_col)[dv].agg(["mean", "std", "count"]).round(3)

def welch_ttest(x1, x2):
    """Welch's t-test returning t, df, p, 95% CI for mean difference."""
    x1 = np.asarray(x1, dtype=float)
    x2 = np.asarray(x2, dtype=float)
    t, p = stats.ttest_ind(x1, x2, equal_var=False)
    m_diff = x1.mean() - x2.mean()
    se = np.sqrt(x1.var(ddof=1) / len(x1) + x2.var(ddof=1) / len(x2))
    df_w = ((x1.var(ddof=1) / len(x1) + x2.var(ddof=1) / len(x2)) ** 2 /
            ((x1.var(ddof=1) / len(x1)) ** 2 / (len(x1) - 1) +
             (x2.var(ddof=1) / len(x2)) ** 2 / (len(x2) - 1)))
    tcrit = stats.t.ppf(0.975, df_w)
    return {
        "t": float(t), "df": float(df_w), "p": float(p),
        "mean_diff": float(m_diff),
        "ci_low": float(m_diff - tcrit * se),
        "ci_high": float(m_diff + tcrit * se),
    }
