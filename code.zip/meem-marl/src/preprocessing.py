"""
Preprocessing pipeline .

Pipeline: median filter → z-score → sliding window → PCA (95% variance) → SMOTE.
Runs on any (n_windows, n_channels, n_samples) multimodal tensor.
"""

import numpy as np
from scipy.signal import medfilt
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from . import config as C
from .utils import smote_generate

# ============================================================
# Step 1: Median filter
# ============================================================
def median_filter_signal(x, window=C.MEDIAN_FILTER_WINDOW):
    """Remove outliers with a median filter of the specified odd window size."""
    window = window if window % 2 == 1 else window + 1
    if x.ndim == 1:
        return medfilt(x, kernel_size=window)
    result = np.empty_like(x)
    for i in range(x.shape[0]):
        result[i] = medfilt(x[i], kernel_size=window)
    return result

# ============================================================
# Step 2: Z-score normalization
# ============================================================
def zscore_normalize(x, axis=-1):
    """Standardise to mean 0, unit variance along the given axis."""
    mu = x.mean(axis=axis, keepdims=True)
    sd = x.std(axis=axis, keepdims=True) + 1e-9
    return (x - mu) / sd

# ============================================================
# Step 3: Sliding window
# ============================================================
def sliding_window(x, window_size=C.SAMPLES_PER_WINDOW, overlap=C.SLIDING_OVERLAP):
    """
    Cut a 1-D or 2-D signal into overlapping windows of size window_size.
    Returns array of shape (n_windows, ..., window_size).
    """
    hop = int(window_size * (1.0 - overlap))
    if hop < 1:
        hop = 1
    n = x.shape[-1]
    n_windows = max((n - window_size) // hop + 1, 0)
    if n_windows == 0:
        return np.empty((0,) + x.shape[:-1] + (window_size,))
    starts = np.arange(n_windows) * hop
    out = np.stack([x[..., s:s + window_size] for s in starts], axis=0)
    return out

# ============================================================
# Step 4: PCA - the equation
# ============================================================
class PCAReducer:
    """
    Y = X · W
    W collects the top eigenvectors of the covariance matrix explaining >= 95 % variance.
    """
    def __init__(self, variance_kept=C.PCA_VARIANCE_KEPT):
        self.variance_kept = variance_kept
        self.pca = None
        self.scaler = StandardScaler()

    def fit(self, X):
        Xn = self.scaler.fit_transform(X)
        self.pca = PCA(n_components=self.variance_kept, svd_solver="full")
        self.pca.fit(Xn)
        return self

    def transform(self, X):
        Xn = self.scaler.transform(X)
        return self.pca.transform(Xn)

    def fit_transform(self, X):
        self.fit(X)
        return self.transform(X)

    @property
    def n_components_(self):
        return self.pca.n_components_ if self.pca else 0

    @property
    def explained_variance_ratio_(self):
        return self.pca.explained_variance_ratio_ if self.pca else np.array([])

# ============================================================
# Step 5: SMOTE
# ============================================================
def apply_smote(X, y, k=C.SMOTE_K, rng=None):
    """
    Class-balance a training fold using SMOTE .
    Only call inside a training fold — never across the whole dataset.
    """
    if rng is None:
        rng = np.random.default_rng(C.GLOBAL_SEED)
    X = np.asarray(X)
    y = np.asarray(y)
    classes, counts = np.unique(y, return_counts=True)
    n_max = counts.max()
    Xs, ys = [X], [y]
    for cls, cnt in zip(classes, counts):
        deficit = n_max - cnt
        if deficit <= 0:
            continue
        x_min = X[y == cls]
        if len(x_min) < 2:
            continue
        k_eff = min(k, len(x_min) - 1)
        x_syn = smote_generate(x_min, k=k_eff, n_synth=deficit, rng=rng)
        Xs.append(x_syn)
        ys.append(np.full(deficit, cls))
    return np.vstack(Xs), np.concatenate(ys)

# ============================================================
# Kernel density estimation - the equation
# ============================================================
def kernel_density_2d(points, x_grid, y_grid, bandwidth=None):
    """
    Gaussian KDE for fixation heat maps.
    f(x, y) = 1/(nh^2) * sum_i K((x - xi)/h, (y - yi)/h)
    """
    points = np.asarray(points, dtype=float)
    n = len(points)
    if bandwidth is None:
        # Silverman's rule
        bandwidth = 1.06 * np.std(points) * n ** (-1 / 5)
    X, Y = np.meshgrid(x_grid, y_grid)
    density = np.zeros_like(X)
    h = bandwidth
    coef = 1.0 / (n * 2 * np.pi * h * h)
    for xi, yi in points:
        density += np.exp(-((X - xi) ** 2 + (Y - yi) ** 2) / (2 * h * h))
    return density * coef

# ============================================================
# Multimodal resampling to common 50 Hz grid
# ============================================================
def resample_to_common_grid(signal, native_hz, target_hz=C.COMMON_SAMPLING_HZ):
    """Linear resampling of a 1-D signal to a common grid."""
    n_native = len(signal)
    duration = n_native / native_hz
    n_target = int(round(duration * target_hz))
    if n_target <= 1:
        return signal
    t_native = np.linspace(0, duration, n_native)
    t_target = np.linspace(0, duration, n_target)
    return np.interp(t_target, t_native, signal)

# ============================================================
# Full preprocessing pipeline
# ============================================================
def preprocess_multimodal(signals: dict, native_hz: dict) -> dict:
    """
    Apply the full preprocessing chain to a dict of {modality: signal_array}.
    Returns a dict of {modality: (n_windows, samples_per_window)} arrays.
    """
    processed = {}
    for modality, sig in signals.items():
        if native_hz.get(modality) is None:
            continue
        # 1. Resample to common grid
        sig_r = resample_to_common_grid(sig, native_hz[modality])
        # 2. Median filter
        sig_f = median_filter_signal(sig_r)
        # 3. Z-score
        sig_n = zscore_normalize(sig_f)
        # 4. Sliding window
        sig_w = sliding_window(sig_n)
        processed[modality] = sig_w
    return processed

if __name__ == "__main__":
    # Self-test
    rng = np.random.default_rng(C.GLOBAL_SEED)
    fake = {
        "eye":   rng.standard_normal(120 * 10),
        "face":  rng.standard_normal(30 * 10),
        "voice": rng.standard_normal(16000 * 2),
        "hrv":   rng.standard_normal(1000 * 2),
        "eda":   rng.standard_normal(128 * 10),
        "logs":  rng.standard_normal(50 * 10),
    }
    hz = {"eye": 120, "face": 30, "voice": 16000,
          "hrv": 1000, "eda": 128, "logs": 50}
    out = preprocess_multimodal(fake, hz)
    for k, v in out.items():
        print(f"{k}: windows shape = {v.shape}")

    # PCA + SMOTE demo
    X = rng.standard_normal((200, 40))
    y = np.array([0] * 150 + [1] * 40 + [2] * 10)
    reducer = PCAReducer(variance_kept=0.95)
    Xp = reducer.fit_transform(X)
    Xb, yb = apply_smote(Xp, y)
    print(f"PCA components retained: {reducer.n_components_}")
    print(f"After SMOTE, class balance:", np.bincount(yb))
