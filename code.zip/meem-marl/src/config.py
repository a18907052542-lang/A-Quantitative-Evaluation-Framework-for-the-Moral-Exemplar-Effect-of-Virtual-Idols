"""
Global configuration for MEEM-MARL.
Constants map directly to values reported in Sections 3.1.1, 3.2.1 and .
"""

import os
from pathlib import Path

# ---------------- Paths ----------------
PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR     = PROJECT_ROOT / "data"
OUTPUTS_DIR  = PROJECT_ROOT / "outputs"
TABLES_DIR   = OUTPUTS_DIR / "tables"
FIGURES_DIR  = OUTPUTS_DIR / "figures"
LOGS_DIR     = OUTPUTS_DIR / "logs"

for d in (OUTPUTS_DIR, TABLES_DIR, FIGURES_DIR, LOGS_DIR):
    d.mkdir(parents=True, exist_ok=True)

DATASET_FILE = DATA_DIR / "Raw_Dataset.xlsx"

# ---------------- Reproducibility ----------------
GLOBAL_SEED = 20240315         # matches ethics-approval date

# ---------------- Study design ----------------
ARMS = ["Control", "Virtual Idol", "Traditional"]
ARM_COLORS = {
    "Control":      "#2E5C8A",     # dark blue
    "Virtual Idol": "#3E9C88",     # teal
    "Traditional":  "#E09B4A",     # amber
}
ARM_MARKERS = {
    "Control":      "o",
    "Virtual Idol": "s",
    "Traditional":  "^",
}

# ---------------- Preprocessing  ----------------
MEDIAN_FILTER_WINDOW = 5
ZSCORE_MU            = 0.0
ZSCORE_SIGMA         = 1.0
SLIDING_WINDOW_SIZE  = 2.0     # seconds
SLIDING_OVERLAP      = 0.5     # 50 % overlap
PCA_VARIANCE_KEPT    = 0.95
SMOTE_K              = 5

# ---------------- Sensor grid  ----------------
COMMON_SAMPLING_HZ = 50        # resample grid
SAMPLES_PER_WINDOW = int(SLIDING_WINDOW_SIZE * COMMON_SAMPLING_HZ)   # 100 samples/channel

# ---------------- Modality set (the pipeline) ----------------
MODALITIES = ["eye", "face", "voice", "hrv", "eda", "logs"]  # EEG optional, not acquired
FUSED_FEATURE_DIM = 128        # d_f
LATENT_STATE_DIM  = 64

# ---------------- Loss weighting  ----------------
LAMBDA_AFF   = 1.0
LAMBDA_MORAL = 0.7
LAMBDA_REG   = 1e-4

# ---------------- Reward weighting  ----------------
REWARD_W_MC = 0.30             # w_1
REWARD_W_ME = 0.30             # w_2
REWARD_W_BI = 0.30             # w_3
REWARD_W_CL = 0.10             # w_4 cognitive load penalty
REWARD_W_D  = 0.15             # w_5 dependence penalty

# ---------------- Q-learning ----------------
DISCOUNT_GAMMA = 0.95
LR_Q           = 0.10
EPS_START      = 0.30
EPS_END        = 0.05
EPS_ANNEAL_WIN = 60            # anneal over first 60 windows

# ---------------- Action space A_VI (Step 7) ----------------
ACTIONS = ["expression", "tone", "content", "pacing"]

# ---------------- Emotion classes ----------------
EMOTION_CLASSES = ["Neutral", "Happiness", "Surprise", "Sadness",
                    "Anger", "Fear", "Disgust"]

# ---------------- Analysis parameters ----------------
ALPHA = 0.05
POWER = 0.80
FAMILYWISE_CORRECTION = "holm-bonferroni"
BOOTSTRAP_RESAMPLES   = 10_000

# ---------------- Deployment tiers (2) ----------------
DEPLOYMENT_TIERS = {
    "Full":     ["eye", "face", "voice", "hrv", "eda", "logs"],
    "Standard": ["face", "voice", "logs"],
    "Minimal":  ["logs"],
}

# ---------------- Font settings for figures ----------------
FONT_FAMILY = "DejaVu Sans"   # cross-platform sans-serif rendering
