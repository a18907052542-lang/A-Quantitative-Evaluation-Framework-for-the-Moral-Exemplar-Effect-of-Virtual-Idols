# MEEM-MARL

**Moral Exemplar Effect Model with Multimodal Affective Reinforcement Learning.**

Companion analysis codebase for the study *A Quantitative Evaluation Framework for the Moral Exemplar Effect of Virtual Idols Based on Attention-Weighted Multimodal Fusion: Evidence from a Randomized Controlled Trial in Chinese Higher Education.*

Ethics approval: HVU-2024032 (Research Ethics Committee of Hainan Vocational University), approved 15 March 2024.

## Repository structure

```
meem-marl/
├── README.md
├── requirements.txt
├── data/
│   └── Raw_Dataset.xlsx            # 12-sheet raw dataset (198 participants + pilot corpora)
├── src/
│   ├── config.py                   # Global configuration and hyperparameters
│   ├── utils.py                    # Statistical helpers (Cronbach's alpha, Cohen's d, mediation bootstrap)
│   ├── preprocessing.py            # Preprocessing pipeline (median filter, z-score, sliding window, PCA, SMOTE)
│   └── model.py                    # MEEM-MARL model (encoders, fusion, moral modeling, Q-learning)
├── analysis/
│   ├── descriptive.py              # Baseline characteristics and internal consistency
│   ├── rct_analysis.py             # Primary outcomes across three time points, effect sizes
│   ├── engagement.py               # Engagement, physiological, and exposure-adjustment analyses
│   ├── mediation.py                # Mediation, structural equation modeling, moderation
│   ├── retention_ablation.py       # Long-term retention, pipeline component ablation
│   └── sensitivity.py              # Sensitivity analyses across six specifications
├── figures/
│   └── figure_generator.py         # Manuscript figure set
├── outputs/                        # Populated on first run
│   ├── tables/                     # CSV outputs of every table
│   ├── figures/                    # PNG outputs of every figure
│   └── logs/                       # Analysis logs
├── main.py                         # One-shot pipeline
└── run_model_demo.py               # Model forward-pass demonstration
```

## Requirements

Python >= 3.9. Install with:

```bash
pip install -r requirements.txt
```

## Running the full analysis pipeline

```bash
python main.py                    # Runs every analysis, writes to outputs/
python run_model_demo.py          # Runs the model forward pass on demo inputs
```

Individual analyses are also runnable directly:

```bash
python analysis/rct_analysis.py
python figures/figure_generator.py --figure 7
```

## Method summary

- **Multimodal acquisition**: eye tracking (Tobii Pro Fusion, 120 Hz), facial video (1080p webcam, 30 Hz), speech prosody (16 kHz), HRV (1000 Hz), EDA (128 Hz), event-driven interaction logs.
- **Preprocessing**: median filter -> z-score -> sliding window (2 s, 50% overlap) -> PCA (95% variance retained) -> SMOTE (k = 5, within training fold only).
- **Per-modality encoders**: 1-D CNN over eye-tracking channels, CNN with facial action-unit features, Transformer over acoustic features, LSTM over HRV and EDA, MLP over aggregated interaction logs.
- **Attention-weighted late fusion**: alpha_m = softmax(w_a^T F_m + b_a), learned end-to-end.
- **Latent state estimation**: CNN-LSTM affect head plus engagement, presence, and cognitive-load heads.
- **Three-stage moral modeling**: Attention -> Retention -> Reproduction.
- **Q-learning policy optimization**: over the action space {expression, tone, content, pacing}, with a dependence-penalty reward safeguarding against parasocial over-attachment.

## Public datasets used for pre-training

The affect estimator is pre-trained on two publicly released datasets before fine-tuning on the multimodal pilot corpus.

- **CH-SIMS** (2,281 Chinese multimodal video segments): https://github.com/thuiar/MMSA
- **DEAP** (32-participant peripheral physiological signals): http://www.eecs.qmul.ac.uk/mmv/datasets/deap/

## Contact

Principal Investigator: Xinggan Fu (fxg0630@163.com), School of Marxism, Hainan Vocational University, Haikou, Hainan, 570216, China.
