"""
MEEM-MARL model forward-pass demonstration.
Runs the full pipeline (the pipeline) on multimodal windows.

Usage:
    python run_model_demo.py
"""

import sys
import time
import numpy as np
import torch
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from src import config as C
from src.model import (
    MEEMMARL, composite_loss, compute_reward,
    QLearningPolicy, measure_latency,
)
from src.preprocessing import (
    preprocess_multimodal, PCAReducer, apply_smote,
)

def make_demo_windows(batch_size=8):
    """Build a multimodal batch consistent with ."""
    torch.manual_seed(C.GLOBAL_SEED)
    return {
        "eye":    torch.randn(batch_size, 4, 100),          # 4 channels × 100 samples
        "face":   torch.randn(batch_size, 85, 100),         # 68 landmarks + 17 AUs
        "voice":  torch.randn(batch_size, 100, 88),         # 88 eGeMAPS features
        "physio": torch.randn(batch_size, 100, 6),          # HRV + EDA
        "logs":   torch.randn(batch_size, 10),              # aggregated log features
    }

def make_demo_targets(batch_size=8):
    torch.manual_seed(C.GLOBAL_SEED + 1)
    return {
        "emotion_class":     torch.randint(0, 7, (batch_size,)),
        "valence_arousal":   torch.randn(batch_size, 2) * 0.5,
        "y_mc":              torch.rand(batch_size),
        "y_me":              torch.rand(batch_size),
        "y_bi":              torch.rand(batch_size),
    }

def demo_preprocessing():
    print("\n" + "=" * 70)
    print("PREPROCESSING PIPELINE DEMO")
    print("=" * 70)
    rng = np.random.default_rng(C.GLOBAL_SEED)
    # 10 seconds of six modalities at native sampling rates
    signals = {
        "eye":   rng.standard_normal(120 * 10),
        "face":  rng.standard_normal(30 * 10),
        "voice": rng.standard_normal(16000 * 2),
        "hrv":   rng.standard_normal(1000 * 2),
        "eda":   rng.standard_normal(128 * 10),
        "logs":  rng.standard_normal(50 * 10),
    }
    native_hz = {"eye": 120, "face": 30, "voice": 16000,
                  "hrv": 1000, "eda": 128, "logs": 50}
    processed = preprocess_multimodal(signals, native_hz)
    for k, v in processed.items():
        print(f"  {k}: windows shape = {v.shape}")

    # PCA demo
    X = rng.standard_normal((200, 40))
    reducer = PCAReducer(variance_kept=0.95)
    Xp = reducer.fit_transform(X)
    print(f"\n  PCA: 40 → {reducer.n_components_} components "
           f"(cumulative variance {reducer.explained_variance_ratio_.sum():.3f})")

    # SMOTE demo
    y = np.array([0] * 150 + [1] * 40 + [2] * 10)
    Xb, yb = apply_smote(Xp, y)
    print(f"  SMOTE class balance: {dict(zip(*np.unique(yb, return_counts=True)))}")

def demo_forward_pass():
    print("\n" + "=" * 70)
    print("MEEM-MARL FORWARD PASS (the pipeline)")
    print("=" * 70)
    model = MEEMMARL()
    model.eval()

    inputs = make_demo_windows(batch_size=8)
    with torch.no_grad():
        out = model(inputs)

    print(f"  Fused feature dim (d_f): {C.FUSED_FEATURE_DIM}")
    print(f"  Attention weights shape (B, M): {out['attention_weights'].shape}")
    print(f"  Sample attention weights (first participant): "
           f"{out['attention_weights'][0].numpy().round(3)}")
    print(f"  Affect logits shape:  {out['affect_logits'].shape}")
    print(f"  Latent moral state z_p shape: {out['z_p'].shape}")
    print(f"  Y_MC output: {out['y_mc'][:4].numpy().round(3)}")
    print(f"  Y_ME output: {out['y_me'][:4].numpy().round(3)}")
    print(f"  Y_BI output: {out['y_bi'][:4].numpy().round(3)}")

    n_params = sum(p.numel() for p in model.parameters())
    print(f"\n  Total learnable parameters: {n_params:,}")

def demo_composite_loss():
    print("\n" + "=" * 70)
    print("COMPOSITE LOSS ")
    print("=" * 70)
    model = MEEMMARL()
    inputs = make_demo_windows()
    targets = make_demo_targets()
    out = model(inputs)
    L = composite_loss(out, targets,
                        lam_aff=C.LAMBDA_AFF,
                        lam_moral=C.LAMBDA_MORAL,
                        lam_reg=C.LAMBDA_REG,
                        parameters=list(model.parameters()))
    print(f"  L_total = lam_aff * L_aff + lam_moral * L_moral + lam_reg * ||theta||^2")
    print(f"  lam_aff   = {C.LAMBDA_AFF}")
    print(f"  lam_moral = {C.LAMBDA_MORAL}")
    print(f"  lam_reg   = {C.LAMBDA_REG}")
    print(f"  L_total   = {L.item():.4f}")

def demo_reward():
    print("\n" + "=" * 70)
    print("REWARD FUNCTION (dependence penalty)")
    print("=" * 70)
    deltas = {
        "delta_mc": 0.20, "delta_me": 0.15, "delta_bi": 0.10,
        "cognitive_load": 0.3,
    }
    for label, w5, D in [
        ("As deployed (no penalty)",   0.00, 0.41),
        ("Specified (w5 = 0.15)",       0.15, 0.28),
        ("Heavy penalty (w5 = 0.30)",   0.30, 0.19),
    ]:
        R = compute_reward(
            deltas["delta_mc"], deltas["delta_me"], deltas["delta_bi"],
            deltas["cognitive_load"], D,
            w1=C.REWARD_W_MC, w2=C.REWARD_W_ME, w3=C.REWARD_W_BI,
            w4=C.REWARD_W_CL, w5=w5,
        )
        print(f"  {label:35s} R = {R:.4f}   (D = {D})")

def demo_qlearning():
    print("\n" + "=" * 70)
    print("Q-LEARNING POLICY UPDATE (Step 7)")
    print("=" * 70)
    policy = QLearningPolicy()
    rng = np.random.default_rng(C.GLOBAL_SEED)

    # Warm start (offline pilot corpus)
    n_warm = 500
    print(f"  Warm-starting on {n_warm} transitions...")
    for _ in range(n_warm):
        s = rng.random(5)
        a = int(rng.integers(0, len(C.ACTIONS)))
        r = rng.random()
        sp = rng.random(5)
        policy.update(s, a, r, sp)

    # Online session
    print("  Running online session (858 windows, 2-second cadence)...")
    action_switches = 0
    prev_a = None
    n_online = 858
    td_errors = []
    for step in range(n_online):
        s = rng.random(5)
        a = policy.select(s)
        r = rng.random() * 0.5
        sp = rng.random(5)
        td = policy.update(s, a, r, sp)
        td_errors.append(td)
        if prev_a is not None and a != prev_a:
            action_switches += 1
        prev_a = a
    switch_rate = action_switches / (n_online - 1)
    print(f"  Q-table size: {len(policy.Q)} states")
    print(f"  Action-switching rate:   {switch_rate:.3f}")
    print(f"  Mean |TD| error:         {np.mean(td_errors):.3f}")
    print(f"  Final epsilon:           {policy._epsilon():.3f}")

    # Optimal action given some state
    s_query = np.array([0.5, 0.7, 0.6, 0.3, 0.5])
    a_star = policy.policy_star(s_query)
    print(f"  Optimal action for query state: '{a_star}'")

def demo_latency():
    print("\n" + "=" * 70)
    print("END-TO-END LATENCY ")
    print("=" * 70)
    print("  Measuring 200 forward passes...")
    model = MEEMMARL()
    inputs = make_demo_windows(batch_size=1)
    stats = measure_latency(model, inputs, n_runs=200)
    for k, v in stats.items():
        print(f"  {k:20s}: {v:.2f}")

def main():
    print("\n" + "#" * 70)
    print("#  MEEM-MARL MODEL FORWARD-PASS DEMONSTRATION")
    print("#  Implements the pipeline (Steps 1–8) end-to-end.")
    print("#" * 70)

    t0 = time.time()
    demo_preprocessing()
    demo_forward_pass()
    demo_composite_loss()
    demo_reward()
    demo_qlearning()
    demo_latency()

    print("\n" + "#" * 70)
    print(f"#  Demo complete in {time.time() - t0:.1f} seconds")
    print("#" * 70)

if __name__ == "__main__":
    main()
