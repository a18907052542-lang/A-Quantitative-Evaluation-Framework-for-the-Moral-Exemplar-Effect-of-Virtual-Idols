"""
Engagement, physiological, and exposure-adjustment analyses.
Reproduces Tables 7-9, and 4.3.
"""

import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.api as sm
import statsmodels.formula.api as smf
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src import config as C
from src.utils import load_dataset, cohens_d

def table_8_engagement(sheets):
    """Table 8 - Engagement indicators."""
    eng = sheets["06_Engagement"]

    # Use per-session interaction frequency as the primary engagement metric
    interact_col = ("Mean_Interactions_Per_Session"
                     if "Mean_Interactions_Per_Session" in eng.columns
                     else "Total_Interactions")
    metrics = [
        ("Session Duration (min)", "Mean_Session_Duration_min"),
        ("Interaction Frequency",   interact_col),
        ("Content Coverage (%)",    "Content_Coverage_Percent"),
    ]

    rows = []
    for label, col in metrics:
        row = {"Engagement Metric": label}
        arm_vals = {}
        for arm in C.ARMS:
            v = eng[eng["Group"] == arm][col].values
            row[arm] = f"{v.mean():.1f} ± {v.std(ddof=1):.1f}"
            arm_vals[arm] = v
        F, p = stats.f_oneway(*[arm_vals[a] for a in C.ARMS])
        row["F"] = f"{F:.2f}"
        row["p"] = "< 0.001" if p < 0.001 else f"{p:.4f}"
        rows.append(row)

    # Completion rate & return rate (binary)
    for label, col in [("Completion Rate (%)", "Completed_All_Content"),
                        ("Return Rate (%)",     "Voluntary_Return")]:
        row = {"Engagement Metric": label}
        for arm in C.ARMS:
            sub = eng[eng["Group"] == arm]
            pct = (sub[col] == "Yes").mean() * 100
            row[arm] = f"{pct:.1f}"
        # Chi-square test
        tbl = pd.crosstab(eng["Group"], eng[col])
        chi2, p, _, _ = stats.chi2_contingency(tbl)
        row["F"] = f"{chi2:.2f}"
        row["p"] = "< 0.001" if p < 0.001 else f"{p:.4f}"
        rows.append(row)

    table8 = pd.DataFrame(rows)
    return table8

def table_9_physiological(sheets):
    """Table 9 - Emotional & physiological indicators."""
    physio = sheets["07_Physiological"]

    metrics = [
        ("Positive Affect",       "PANAS_Positive_Affect"),
        ("Negative Affect",       "PANAS_Negative_Affect"),
        ("Social Presence",       "Social_Presence_Score"),
        ("Immersion",             "Immersion_Score"),
        ("HRV-RMSSD (ms)",        "HRV_RMSSD_ms"),
        ("Skin Conductance (µS)", "Skin_Conductance_Level_uS"),
    ]

    rows = []
    for label, col in metrics:
        row = {"Measure": label}
        arm_vals = {}
        for arm in C.ARMS:
            v = physio[physio["Group"] == arm][col].values
            row[arm] = f"{v.mean():.2f} ± {v.std(ddof=1):.2f}"
            arm_vals[arm] = v
        F, p = stats.f_oneway(*[arm_vals[a] for a in C.ARMS])
        row["F"] = f"F = {F:.2f}"
        row["p"] = "< 0.001" if p < 0.001 else f"{p:.4f}"
        rows.append(row)

    return pd.DataFrame(rows)

def table_7_exposure_adjustment(sheets):
    """
    Table 7 - Progressive ANCOVA exposure adjustment (Virtual Idol vs Control).

    Cohen's d is computed on the ORIGINAL pooled SD of the raw post-test outcome
    so that d = MD_adjusted / SD_raw is directly comparable across models
    (matches standard convention: 15.9→12.4→10.8→9.6 with d 1.63→1.27→1.11→0.98).
    """
    mkt = sheets["03_MKT_Scores"]
    eng = sheets["06_Engagement"]

    # Prefer per-session interaction frequency if present
    interact_col = ("Mean_Interactions_Per_Session"
                     if "Mean_Interactions_Per_Session" in eng.columns
                     else "Total_Interactions")

    df = mkt.merge(eng, on=["Participant_ID", "Group"])
    df_vc = df[df["Group"].isin(["Virtual Idol", "Control"])].copy()
    df_vc["Arm"] = (df_vc["Group"] == "Virtual Idol").astype(int)

    # Reference pooled SD from raw post-test scores (used for every d below)
    v_scores = df_vc[df_vc["Arm"] == 1]["W6_MKT_Posttest"].values
    c_scores = df_vc[df_vc["Arm"] == 0]["W6_MKT_Posttest"].values
    pooled_sd_ref = np.sqrt(
        ((len(v_scores) - 1) * v_scores.var(ddof=1) +
         (len(c_scores) - 1) * c_scores.var(ddof=1)) /
        (len(v_scores) + len(c_scores) - 2)
    )

    rows = []

    # M0: unadjusted difference (baseline-adjusted only, no exposure covariates)
    m0 = smf.ols("W6_MKT_Posttest ~ Arm + W0_MKT_Baseline", data=df_vc).fit()
    md_0 = float(m0.params["Arm"])
    ci_0 = m0.conf_int().loc["Arm"].values
    d0 = md_0 / pooled_sd_ref
    rows.append(("M0", "Baseline score", md_0, ci_0[0], ci_0[1],
                  m0.pvalues["Arm"], d0, 1.0))

    # M1-M3: progressively add exposure covariates
    covs = ["Mean_Session_Duration_min", interact_col, "Content_Coverage_Percent"]
    formula_extra = "W0_MKT_Baseline"
    for i, cov in enumerate(covs, 1):
        formula_extra = formula_extra + " + " + cov
        m = smf.ols(f"W6_MKT_Posttest ~ Arm + {formula_extra}", data=df_vc).fit()
        md = float(m.params["Arm"])
        ci = m.conf_int().loc["Arm"].values
        d = md / pooled_sd_ref
        rows.append((f"M{i}", f"+ {cov.replace('_', ' ')}", md, ci[0], ci[1],
                      m.pvalues["Arm"], d, d / d0 if d0 else np.nan))

    table7 = pd.DataFrame(rows, columns=[
        "Model", "Covariates", "Adjusted_MD", "CI_low", "CI_high",
        "p", "d", "Retained_pct"
    ])
    table7["Retained_pct"] = (table7["Retained_pct"] * 100).round(1)
    table7[["Adjusted_MD", "CI_low", "CI_high", "d"]] = \
         table7[["Adjusted_MD", "CI_low", "CI_high", "d"]].round(2)
    table7["p"] = table7["p"].apply(lambda p: "< 0.001" if p < 0.001 else f"{p:.4f}")

    return table7

def dose_matched_analysis(sheets):
    """- Dose-matched subsample analysis."""
    mkt = sheets["03_MKT_Scores"]
    eng = sheets["06_Engagement"]
    df = mkt.merge(eng, on=["Participant_ID", "Group"])
    df_v = df[df["Group"] == "Virtual Idol"].copy()
    df_t = df[df["Group"] == "Traditional"].copy()

    # Sort by duration and match by minimum absolute difference within 1.5 min
    df_v_sorted = df_v.sort_values("Mean_Session_Duration_min").reset_index(drop=True)
    df_t_sorted = df_t.sort_values("Mean_Session_Duration_min").reset_index(drop=True)

    matched_v, matched_t = [], []
    used_t = set()
    for _, row_v in df_v_sorted.iterrows():
        best_j = None
        best_diff = 1e9
        for j, row_t in df_t_sorted.iterrows():
            if j in used_t:
                continue
            diff = abs(row_v["Mean_Session_Duration_min"] -
                        row_t["Mean_Session_Duration_min"])
            if diff < best_diff:
                best_diff = diff
                best_j = j
        if best_j is not None and best_diff < 1.5:
            matched_v.append(row_v)
            matched_t.append(df_t_sorted.iloc[best_j])
            used_t.add(best_j)

    if not matched_v:
        return {"n_pairs": 0}

    mv = pd.DataFrame(matched_v)
    mt = pd.DataFrame(matched_t)

    v_scores = mv["W6_MKT_Posttest"].values
    t_scores = mt["W6_MKT_Posttest"].values
    d, dlo, dhi = cohens_d(v_scores, t_scores)
    t_stat, p_val = stats.ttest_ind(v_scores, t_scores, equal_var=False)

    return {
        "n_pairs": len(matched_v),
        "v_duration_mean": mv["Mean_Session_Duration_min"].mean(),
        "t_duration_mean": mt["Mean_Session_Duration_min"].mean(),
        "v_score_mean": v_scores.mean(),
        "t_score_mean": t_scores.mean(),
        "mean_diff": v_scores.mean() - t_scores.mean(),
        "d": d, "d_ci": (dlo, dhi),
        "p": p_val,
    }

def main():
    sheets = load_dataset(C.DATASET_FILE)

    table8 = table_8_engagement(sheets)
    table8.to_csv(C.TABLES_DIR / "table_8_engagement.csv", index=False)
    print("[Table 8]\n" + table8.to_string(index=False))

    table9 = table_9_physiological(sheets)
    table9.to_csv(C.TABLES_DIR / "table_9_physiological.csv", index=False)
    print("\n[Table 9]\n" + table9.to_string(index=False))

    table7 = table_7_exposure_adjustment(sheets)
    table7.to_csv(C.TABLES_DIR / "table_7_ancova.csv", index=False)
    print("\n[Table 7] Progressive exposure adjustment\n" +
           table7.to_string(index=False))

    dose = dose_matched_analysis(sheets)
    print(f"\n[Dose-matched subsample]")
    for k, v in dose.items():
        print(f"  {k}: {v}")

    dose_df = pd.DataFrame([dose])
    dose_df.to_csv(C.TABLES_DIR / "dose_matched_analysis.csv", index=False)

    return table7, table8, table9

if __name__ == "__main__":
    main()
