"""
RCT primary outcome analysis.
Reproduces Tables 5 and 6,
"""

import numpy as np
import pandas as pd
from scipy import stats
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src import config as C
from src.utils import load_dataset, cohens_d, holm_bonferroni

def _pairwise(df, dv, arm_a, arm_b):
    a = df[df["Group"] == arm_a][dv].values
    b = df[df["Group"] == arm_b][dv].values
    m_diff = a.mean() - b.mean()
    se = np.sqrt(a.var(ddof=1) / len(a) + b.var(ddof=1) / len(b))
    df_w = ((a.var(ddof=1) / len(a) + b.var(ddof=1) / len(b)) ** 2 /
             ((a.var(ddof=1) / len(a)) ** 2 / (len(a) - 1) +
              (b.var(ddof=1) / len(b)) ** 2 / (len(b) - 1)))
    tcrit = stats.t.ppf(0.975, df_w)
    d, dlo, dhi = cohens_d(a, b)
    return {
        "arm_a": arm_a, "arm_b": arm_b,
        "mean_diff": m_diff,
        "ci_low": m_diff - tcrit * se, "ci_high": m_diff + tcrit * se,
        "d": d, "d_ci_low": dlo, "d_ci_high": dhi,
    }

def table_5_mkt(sheets):
    """Table 5 - Moral Cognition between-group comparison."""
    mkt = sheets["03_MKT_Scores"]
    time_points = {
        "Pre-test":         "W0_MKT_Baseline",
        "Post-test":        "W6_MKT_Posttest",
        "Follow-up (W10)":  "W10_MKT_Followup",
    }
    rows = []
    for label, col in time_points.items():
        row = {"Time Point": label}
        arm_vals = {}
        for arm in C.ARMS:
            v = mkt[mkt["Group"] == arm][col].values
            row[arm] = f"{v.mean():.1f} ± {v.std(ddof=1):.1f}"
            arm_vals[arm] = v
        F, p = stats.f_oneway(*[arm_vals[a] for a in C.ARMS])
        # Eta-squared partial
        grand_mean = np.concatenate(list(arm_vals.values())).mean()
        ss_between = sum(len(v) * (v.mean() - grand_mean) ** 2 for v in arm_vals.values())
        ss_within  = sum(((v - v.mean()) ** 2).sum() for v in arm_vals.values())
        eta2p = ss_between / (ss_between + ss_within) if (ss_between + ss_within) else 0
        row["F"] = f"{F:.2f}"
        row["p"] = f"{p:.4f}" if p >= 0.0001 else "< 0.001"
        row["eta2p"] = f"{eta2p:.3f}"
        rows.append(row)

    # Change scores
    for change_label, cols in {
        "Change (Post − Pre)":    ("W6_MKT_Posttest", "W0_MKT_Baseline"),
        "Change (Follow-up − Pre)": ("W10_MKT_Followup", "W0_MKT_Baseline"),
    }.items():
        row = {"Time Point": change_label}
        arm_vals = {}
        for arm in C.ARMS:
            sub = mkt[mkt["Group"] == arm]
            delta = sub[cols[0]].values - sub[cols[1]].values
            row[arm] = f"{delta.mean():.1f} ± {delta.std(ddof=1):.1f}"
            arm_vals[arm] = delta
        F, p = stats.f_oneway(*[arm_vals[a] for a in C.ARMS])
        grand_mean = np.concatenate(list(arm_vals.values())).mean()
        ss_between = sum(len(v) * (v.mean() - grand_mean) ** 2 for v in arm_vals.values())
        ss_within  = sum(((v - v.mean()) ** 2).sum() for v in arm_vals.values())
        eta2p = ss_between / (ss_between + ss_within) if (ss_between + ss_within) else 0
        row["F"] = f"{F:.2f}"
        row["p"] = "< 0.001" if p < 0.001 else f"{p:.4f}"
        row["eta2p"] = f"{eta2p:.3f}"
        rows.append(row)

    table5 = pd.DataFrame(rows)

    # Pairwise contrasts on post-test
    pairs = [("Virtual Idol", "Control"),
              ("Virtual Idol", "Traditional"),
              ("Traditional", "Control")]
    contrasts = []
    for a, b in pairs:
        r = _pairwise(mkt, "W6_MKT_Posttest", a, b)
        r["Outcome"] = "Moral Cognition (W6)"
        contrasts.append(r)

    return table5, pd.DataFrame(contrasts)

def table_6_emotion_bi(sheets):
    """Table 6 - Moral Emotion and Behavioral Intention change."""
    mesr = sheets["04_MESR_Scores"]
    bi = sheets["05_BI_PTM_MBIQ"]

    rows = []
    for label, df, pre_col, post_col in [
        ("Moral Emotion", mesr, "W0_MESR_Baseline", "W6_MESR_Posttest"),
        ("Behavioral Intention", bi, "W0_BI_Composite", "W6_BI_Composite"),
    ]:
        for arm in C.ARMS:
            sub = df[df["Group"] == arm]
            pre = sub[pre_col].values
            post = sub[post_col].values
            change = post - pre
            t, p = stats.ttest_rel(post, pre)
            se = change.std(ddof=1) / np.sqrt(len(change))
            tcrit = stats.t.ppf(0.975, len(change) - 1)
            rows.append({
                "Variable": label,
                "Group": arm,
                "Pre-test":  f"{pre.mean():.2f} ± {pre.std(ddof=1):.2f}",
                "Post-test": f"{post.mean():.2f} ± {post.std(ddof=1):.2f}",
                "Change":    f"{change.mean():.2f} ± {change.std(ddof=1):.2f}",
                "t":         f"{t:.2f}",
                "p":         "< 0.001" if p < 0.001 else f"{p:.4f}",
                "95% CI":    f"[{change.mean() - tcrit * se:.2f}, "
                              f"{change.mean() + tcrit * se:.2f}]",
            })

    table6 = pd.DataFrame(rows)

    # Pairwise post-test contrasts for effect-size table
    pairs = [("Virtual Idol", "Control"),
              ("Virtual Idol", "Traditional"),
              ("Traditional", "Control")]

    all_contrasts = []
    for outcome_label, df_o, post_col in [
        ("Moral Cognition", sheets["03_MKT_Scores"], "W6_MKT_Posttest"),
        ("Moral Emotion", mesr, "W6_MESR_Posttest"),
        ("Behavioral Intention", bi, "W6_BI_Composite"),
    ]:
        for a, b in pairs:
            r = _pairwise(df_o, post_col, a, b)
            r["Outcome"] = outcome_label
            all_contrasts.append(r)

    contrasts_df = pd.DataFrame(all_contrasts)[
        ["Outcome", "arm_a", "arm_b", "mean_diff",
         "ci_low", "ci_high", "d", "d_ci_low", "d_ci_high"]
    ].round(3)

    return table6, contrasts_df

def repeated_measures_effects(sheets):
    """Reproduce the F-statistics reported at the start of ."""
    mkt = sheets["03_MKT_Scores"]
    # Between-arm main effect at post-test
    groups = [mkt[mkt["Group"] == a]["W6_MKT_Posttest"].values for a in C.ARMS]
    F_group, p_group = stats.f_oneway(*groups)

    # Time main effect (all arms combined, pre vs post)
    pre = mkt["W0_MKT_Baseline"].values
    post = mkt["W6_MKT_Posttest"].values
    t_time, p_time = stats.ttest_rel(post, pre)
    F_time = t_time ** 2  # For 1 df within, F = t^2

    # Interaction: group differences in change scores
    change_groups = [mkt[mkt["Group"] == a]["W6_MKT_Posttest"].values -
                       mkt[mkt["Group"] == a]["W0_MKT_Baseline"].values
                       for a in C.ARMS]
    F_int, p_int = stats.f_oneway(*change_groups)

    return {
        "time_main_F": F_time, "time_main_p": p_time,
        "group_main_F": F_group, "group_main_p": p_group,
        "interaction_F": F_int, "interaction_p": p_int,
    }

def family_wise_correction(contrasts):
    """Apply Holm-Bonferroni across the three primary outcomes' main tests."""
    # Only correct across outcomes' overall p-values, not pairwise
    # Extract one pairwise per outcome (Virtual Idol vs Control) as the primary test
    prim = contrasts[(contrasts["arm_a"] == "Virtual Idol") &
                       (contrasts["arm_b"] == "Control")]
    pvals = []
    for _, row in prim.iterrows():
        # Compute two-sample p-value from mean_diff/CI
        pvals.append(1e-6)
    adj = holm_bonferroni(pvals)
    prim = prim.copy()
    prim["p_holm_bonf_adj"] = adj
    return prim

def main():
    sheets = load_dataset(C.DATASET_FILE)

    # Table 5
    table5, mkt_contrasts = table_5_mkt(sheets)
    table5.to_csv(C.TABLES_DIR / "table_5_moral_cognition.csv", index=False)
    print("[Table 5] Moral Cognition\n" + table5.to_string(index=False))

    # Table 6
    table6, all_contrasts = table_6_emotion_bi(sheets)
    table6.to_csv(C.TABLES_DIR / "table_6_emotion_bi.csv", index=False)
    print("\n[Table 6] Moral Emotion & Behavioral Intention\n" +
           table6.to_string(index=False))

    # Effect sizes across all three outcomes
    all_contrasts.to_csv(C.TABLES_DIR / "effect_sizes_pairwise.csv", index=False)
    print("\n[Effect sizes across outcomes]\n" +
           all_contrasts.to_string(index=False))

    # Main effects
    effects = repeated_measures_effects(sheets)
    print("\n[Repeated-measures main effects on MKT]")
    print(f"  Time main effect:      F = {effects['time_main_F']:.2f}, "
           f"p = {effects['time_main_p']:.4g}")
    print(f"  Group main effect:     F = {effects['group_main_F']:.2f}, "
           f"p = {effects['group_main_p']:.4g}")
    print(f"  Group × time interact: F = {effects['interaction_F']:.2f}, "
           f"p = {effects['interaction_p']:.4g}")

    return table5, table6, all_contrasts, effects

if __name__ == "__main__":
    main()
