"""
MEEM-MARL project main entry.

Runs the full analysis pipeline: descriptive, RCT, engagement,
mediation, retention, ablation, sensitivity, and figures.

Usage:
    python main.py
"""

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from src import config as C
from src.utils import load_dataset

BANNER = """
================================================================================
  MEEM-MARL: Moral Exemplar Effect Model with Multimodal Affective RL
  Study: Virtual Idols in Chinese Undergraduate Ideological & Moral Education
  Ethics: HVU-2024032 (approved 15 March 2024)
================================================================================
"""

def _step(name):
    print("\n" + "-" * 80)
    print(f">> {name}")
    print("-" * 80)

def run():
    print(BANNER)
    t_all = time.time()

    # Verify dataset present
    if not C.DATASET_FILE.exists():
        raise FileNotFoundError(f"Dataset not found: {C.DATASET_FILE}")
    print(f"Dataset: {C.DATASET_FILE}")
    print(f"Tables output: {C.TABLES_DIR}")
    print(f"Figures output: {C.FIGURES_DIR}")

    sheets = load_dataset(C.DATASET_FILE)
    print(f"Loaded {len(sheets)} sheets from raw dataset.\n")

    # -------- Analysis modules --------
    _step("[1/6] Descriptive statistics & baseline (Table 4)")
    from analysis import descriptive
    descriptive.main()

    _step("[2/6] RCT primary outcomes (Tables 5, 6)")
    from analysis import rct_analysis
    rct_analysis.main()

    _step("[3/6] Engagement, physiological, exposure adjustment (Tables 7-9)")
    from analysis import engagement
    engagement.main()

    _step("[4/6] Mediation, SEM, moderation (Tables 10-11)")
    from analysis import mediation
    mediation.main()

    _step("[5/6] Retention, ablation, dependence penalty (Tables 13, 15-18)")
    from analysis import retention_ablation
    retention_ablation.main()

    _step("[6/6] Sensitivity and task-type analyses (Tables 12, 19)")
    from analysis import sensitivity
    sensitivity.main()

    # -------- Figures --------
    _step("[Figures] Generating Figures 6-14")
    from figures import figure_generator
    figure_generator.generate_all(sheets)

    # -------- Summary --------
    elapsed = time.time() - t_all
    print("\n" + "=" * 80)
    print(f"COMPLETE  ({elapsed:.1f} seconds)")
    print("=" * 80)
    print("\nGenerated tables:")
    for p in sorted(C.TABLES_DIR.glob("*.csv")):
        print(f"  {p.name}")
    print("\nGenerated figures:")
    for p in sorted(C.FIGURES_DIR.glob("*.png")):
        print(f"  {p.name}")

    return True

if __name__ == "__main__":
    run()
